"""
SAM CLI version
"""

__version__ = "1.36.0"
