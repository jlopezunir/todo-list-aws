"""
Constants and helper functions for samconfig.toml's versioning.
"""

SAM_CONFIG_VERSION = 0.1
VERSION_KEY = "version"
